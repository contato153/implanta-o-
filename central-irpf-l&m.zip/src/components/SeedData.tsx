import React, { useState } from 'react';
import { collection, addDoc, getDocs, query, limit } from 'firebase/firestore';
import { db } from '../firebase';
import { Database, Loader2, CheckCircle2 } from 'lucide-react';

export const SeedData: React.FC = () => {
  const [loading, setLoading] = useState(false);
  const [done, setDone] = useState(false);

  const seed = async () => {
    setLoading(true);
    try {
      // Check if already seeded
      const q = query(collection(db, 'clients'), limit(1));
      const snap = await getDocs(q);
      if (!snap.empty) {
        alert('O banco de dados já contém dados. O seed foi cancelado para evitar duplicidade.');
        setLoading(false);
        return;
      }

      // 1. Create Clients
      const clients = [
        { name: 'João Silva', cpf: '12345678901', email: 'joao@email.com', phone: '11999999999', status: 'active', createdAt: new Date().toISOString() },
        { name: 'Maria Oliveira', cpf: '98765432100', email: 'maria@email.com', phone: '11888888888', status: 'active', createdAt: new Date().toISOString() },
        { name: 'Carlos Santos', cpf: '45678912344', email: 'carlos@email.com', phone: '11777777777', status: 'active', createdAt: new Date().toISOString() },
      ];

      const clientIds: string[] = [];
      for (const client of clients) {
        const docRef = await addDoc(collection(db, 'clients'), client);
        clientIds.push(docRef.id);
      }

      // 2. Create Declarations
      const declarations = [
        { 
          clientId: clientIds[0], 
          exerciseYear: 2024, 
          calendarYear: 2023, 
          declarationType: 'Ajuste Anual', 
          kanbanStage: 'waiting_docs', 
          assignedToUserId: 'system',
          priority: 'high',
          grossAmount: 350,
          createdAt: new Date().toISOString() 
        },
        { 
          clientId: clientIds[1], 
          exerciseYear: 2024, 
          calendarYear: 2023, 
          declarationType: 'Ajuste Anual', 
          kanbanStage: 'in_progress', 
          assignedToUserId: 'system',
          priority: 'medium',
          grossAmount: 450,
          createdAt: new Date().toISOString() 
        },
        { 
          clientId: clientIds[2], 
          exerciseYear: 2024, 
          calendarYear: 2023, 
          declarationType: 'Ajuste Anual', 
          kanbanStage: 'transmitted', 
          assignedToUserId: 'system',
          priority: 'low',
          grossAmount: 300,
          createdAt: new Date().toISOString() 
        },
      ];

      const decIds: string[] = [];
      for (const dec of declarations) {
        const docRef = await addDoc(collection(db, 'declarations'), dec);
        decIds.push(docRef.id);
      }

      // 3. Create Pricing History
      for (let i = 0; i < decIds.length; i++) {
        await addDoc(collection(db, 'pricing_history'), {
          clientId: clientIds[i],
          declarationId: decIds[i],
          exerciseYear: 2024,
          grossAmount: declarations[i].grossAmount,
          discountAmount: 0,
          finalAmount: declarations[i].grossAmount,
          paymentStatus: i === 2 ? 'paid' : 'pending',
          paymentMethod: 'Pix',
          dueDate: '2024-04-30',
          createdAt: new Date().toISOString()
        });
      }

      setDone(true);
    } catch (err) {
      console.error('Error seeding data:', err);
      alert('Erro ao gerar dados de exemplo.');
    } finally {
      setLoading(false);
    }
  };

  if (done) {
    return (
      <div className="flex items-center gap-2 text-emerald-600 font-bold text-sm bg-emerald-50 px-4 py-2 rounded-xl border border-emerald-100">
        <CheckCircle2 size={18} />
        Dados gerados com sucesso!
      </div>
    );
  }

  return (
    <button
      onClick={seed}
      disabled={loading}
      className="flex items-center gap-2 bg-slate-800 text-white px-4 py-2 rounded-xl text-sm font-bold hover:bg-slate-900 transition-all shadow-sm disabled:opacity-50"
    >
      {loading ? <Loader2 size={18} className="animate-spin" /> : <Database size={18} />}
      Gerar Dados de Exemplo
    </button>
  );
};
