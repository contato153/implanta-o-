import { 
  collection, 
  getDocs, 
  query, 
  where, 
  addDoc, 
  Timestamp, 
  getDoc, 
  doc,
  orderBy,
  limit
} from 'firebase/firestore';
import { db } from '../firebase';
import { Declaration, PricingHistory, DocumentRequest, Notification, Client } from '../types';
import { format, differenceInDays, parseISO, isAfter, isBefore, addDays } from 'date-fns';

export const automationService = {
  async runAutomations(userId: string) {
    try {
      // 1. Alert for upcoming delivery deadline (within 7 days)
      await this.checkUpcomingDeadlines(userId);

      // 2. Alert for overdue fee
      await this.checkOverdueFees(userId);

      // 3. Alert for cards stuck for many days (e.g., > 10 days in same stage)
      await this.checkStuckCards(userId);

      // 4. Alert for declarations without a sent link
      await this.checkMissingLinks(userId);

    } catch (error) {
      console.error('Error running automations:', error);
    }
  },

  async checkUpcomingDeadlines(userId: string) {
    const q = query(
      collection(db, 'declarations'),
      where('kanbanStage', 'not-in', ['finalized', 'archived'])
    );
    const snapshot = await getDocs(q);
    const now = new Date();
    const sevenDaysFromNow = addDays(now, 7);

    for (const dDoc of snapshot.docs) {
      const decl = { id: dDoc.id, ...dDoc.data() } as Declaration;
      if (!decl.dueDate) continue;
      
      const dueDate = parseISO(decl.dueDate);
      
      if (isAfter(dueDate, now) && isBefore(dueDate, sevenDaysFromNow)) {
        // Check if notification already exists for this declaration and type
        const existing = await this.checkExistingNotification(userId, 'deadline_near', decl.id);
        if (!existing) {
          await this.createNotification(userId, 'deadline_near', decl.id, 
            'Prazo de entrega próximo', 
            `A declaração do exercício ${decl.exerciseYear} vence em ${format(dueDate, 'dd/MM/yyyy')}.`
          );
        }
      }
    }
  },

  async checkOverdueFees(userId: string) {
    const q = query(
      collection(db, 'pricing_history'),
      where('paymentStatus', '==', 'pending'),
      where('dueDate', '!=', null)
    );
    const snapshot = await getDocs(q);
    const now = new Date();

    for (const pDoc of snapshot.docs) {
      const pricing = { id: pDoc.id, ...pDoc.data() } as PricingHistory;
      const dueDate = parseISO(pricing.dueDate);
      
      if (isBefore(dueDate, now)) {
        const existing = await this.checkExistingNotification(userId, 'overdue_fee', pricing.id);
        if (!existing) {
          await this.createNotification(userId, 'overdue_fee', pricing.id, 
            'Honorário Vencido', 
            `O honorário do exercício ${pricing.exerciseYear} está vencido desde ${format(dueDate, 'dd/MM/yyyy')}.`
          );
        }
      }
    }
  },

  async checkStuckCards(userId: string) {
    const q = query(
      collection(db, 'declarations'),
      where('kanbanStage', 'not-in', ['finalized', 'archived'])
    );
    const snapshot = await getDocs(q);
    const now = new Date();

    for (const dDoc of snapshot.docs) {
      const decl = { id: dDoc.id, ...dDoc.data() } as Declaration;
      const updatedAt = parseISO(decl.updatedAt);
      const daysStuck = differenceInDays(now, updatedAt);

      if (daysStuck >= 10) {
        const existing = await this.checkExistingNotification(userId, 'stuck_card', decl.id);
        if (!existing) {
          await this.createNotification(userId, 'stuck_card', decl.id, 
            'Card Parado', 
            `A declaração está na etapa "${decl.kanbanStage}" há ${daysStuck} dias.`
          );
        }
      }
    }
  },

  async checkMissingLinks(userId: string) {
    const q = query(
      collection(db, 'declarations'),
      where('kanbanStage', '==', 'new_service')
    );
    const snapshot = await getDocs(q);

    for (const dDoc of snapshot.docs) {
      const decl = { id: dDoc.id, ...dDoc.data() } as Declaration;
      
      // Check if a document request exists for this declaration
      const reqQ = query(
        collection(db, 'document_requests'),
        where('declarationId', '==', decl.id),
        limit(1)
      );
      const reqSnapshot = await getDocs(reqQ);
      
      if (reqSnapshot.empty) {
        const existing = await this.checkExistingNotification(userId, 'missing_link', decl.id);
        if (!existing) {
          await this.createNotification(userId, 'missing_link', decl.id, 
            'Link não enviado', 
            `A declaração do exercício ${decl.exerciseYear} ainda não possui link de documentos enviado.`
          );
        }
      }
    }
  },

  async checkExistingNotification(userId: string, type: string, entityId: string) {
    const q = query(
      collection(db, 'notifications'),
      where('targetUserId', '==', userId),
      where('type', '==', type),
      where('relatedEntityId', '==', entityId),
      where('readAt', '==', null),
      limit(1)
    );
    const snapshot = await getDocs(q);
    return !snapshot.empty;
  },

  async createNotification(userId: string, type: string, entityId: string, title: string, message: string) {
    await addDoc(collection(db, 'notifications'), {
      targetUserId: userId,
      type,
      relatedEntityId: entityId,
      title,
      message,
      readAt: null,
      createdAt: new Date().toISOString()
    });
  }
};
