import React, { useState, useEffect } from 'react';
import { 
  collection, 
  query, 
  onSnapshot, 
  updateDoc, 
  doc, 
  orderBy,
  where,
  deleteDoc
} from 'firebase/firestore';
import { db, auth } from '../firebase';
import { 
  File, 
  Search, 
  Filter, 
  CheckCircle2, 
  XCircle, 
  Clock, 
  Download, 
  Eye, 
  Trash2,
  User,
  FileText,
  MoreVertical,
  ExternalLink,
  Check,
  X
} from 'lucide-react';
import { 
  UploadedFile, 
  Client, 
  Declaration
} from '../types';
import { handleFirestoreError, OperationType } from '../components/FirebaseProvider';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';

export const Uploads: React.FC = () => {
  const [uploads, setUploads] = useState<UploadedFile[]>([]);
  const [clients, setClients] = useState<Record<string, Client>>({});
  const [declarations, setDeclarations] = useState<Record<string, Declaration>>({});
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');

  useEffect(() => {
    const q = query(collection(db, 'uploaded_files'), orderBy('createdAt', 'desc'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const docs = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as UploadedFile));
      setUploads(docs);
      setLoading(false);
    }, (err) => {
      handleFirestoreError(err, OperationType.GET, 'uploaded_files');
      setLoading(false);
    });

    const unsubscribeClients = onSnapshot(collection(db, 'clients'), (snapshot) => {
      const clientsMap: Record<string, Client> = {};
      snapshot.docs.forEach(doc => {
        clientsMap[doc.id] = { id: doc.id, ...doc.data() } as Client;
      });
      setClients(clientsMap);
    });

    const unsubscribeDeclarations = onSnapshot(collection(db, 'declarations'), (snapshot) => {
      const declarationsMap: Record<string, Declaration> = {};
      snapshot.docs.forEach(doc => {
        declarationsMap[doc.id] = { id: doc.id, ...doc.data() } as Declaration;
      });
      setDeclarations(declarationsMap);
    });

    return () => {
      unsubscribe();
      unsubscribeClients();
      unsubscribeDeclarations();
    };
  }, []);

  const handleUpdateStatus = async (uploadId: string, newStatus: 'approved' | 'refused', reviewNote?: string) => {
    try {
      await updateDoc(doc(db, 'uploaded_files', uploadId), {
        reviewStatus: newStatus,
        reviewNote: reviewNote || '',
        updatedAt: new Date().toISOString()
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `uploaded_files/${uploadId}`);
    }
  };

  const handleDelete = async (uploadId: string) => {
    if (!window.confirm('Tem certeza que deseja excluir este arquivo?')) return;
    try {
      await deleteDoc(doc(db, 'uploaded_files', uploadId));
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, `uploaded_files/${uploadId}`);
    }
  };

  const filteredUploads = uploads.filter(upload => {
    const client = clients[upload.clientId];
    const matchesSearch = client?.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
                         upload.fileNameOriginal.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'all' || upload.reviewStatus === statusFilter;
    return matchesSearch && matchesStatus;
  });

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-slate-800">Uploads / Arquivos</h2>
          <p className="text-slate-500">Central de documentos recebidos dos clientes.</p>
        </div>
      </div>

      {/* Filters */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 bg-white p-4 rounded-xl shadow-sm border border-slate-100">
        <div className="relative md:col-span-2">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
          <input
            type="text"
            placeholder="Buscar por cliente ou nome do arquivo..."
            className="w-full pl-10 pr-4 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <div className="flex items-center gap-2">
          <Filter className="text-slate-400" size={18} />
          <select
            className="w-full p-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
          >
            <option value="all">Todos os Status</option>
            <option value="pending">Pendentes</option>
            <option value="approved">Aprovados</option>
            <option value="refused">Recusados</option>
          </select>
        </div>
      </div>

      {/* Uploads List */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-100 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead className="bg-slate-50 border-bottom border-slate-100">
              <tr>
                <th className="px-6 py-4 text-sm font-semibold text-slate-600">Arquivo</th>
                <th className="px-6 py-4 text-sm font-semibold text-slate-600">Cliente / Declaração</th>
                <th className="px-6 py-4 text-sm font-semibold text-slate-600">Data</th>
                <th className="px-6 py-4 text-sm font-semibold text-slate-600">Status</th>
                <th className="px-6 py-4 text-sm font-semibold text-slate-600">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {loading ? (
                <tr>
                  <td colSpan={5} className="px-6 py-8 text-center text-slate-500">Carregando arquivos...</td>
                </tr>
              ) : filteredUploads.length === 0 ? (
                <tr>
                  <td colSpan={5} className="px-6 py-8 text-center text-slate-500">Nenhum arquivo encontrado.</td>
                </tr>
              ) : (
                filteredUploads.map((upload) => {
                  const client = clients[upload.clientId];
                  const declaration = upload.declarationId ? declarations[upload.declarationId] : null;
                  return (
                    <tr key={upload.id} className="hover:bg-slate-50 transition-colors group">
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 bg-indigo-50 rounded-lg flex items-center justify-center text-indigo-600">
                            <File size={20} />
                          </div>
                          <div>
                            <div className="font-medium text-slate-800 truncate max-w-[200px]" title={upload.fileNameOriginal}>
                              {upload.fileNameOriginal}
                            </div>
                            <div className="text-xs text-slate-400 uppercase tracking-wider">{(upload.mimeType || 'file/unknown').split('/')[1]}</div>
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="text-sm font-medium text-slate-700">{client?.name || 'Cliente Desconhecido'}</div>
                        <div className="text-xs text-slate-500">IRPF {declaration?.exerciseYear || 'N/A'}</div>
                      </td>
                      <td className="px-6 py-4 text-sm text-slate-600">
                        {format(new Date(upload.createdAt), 'dd/MM/yyyy HH:mm')}
                      </td>
                      <td className="px-6 py-4">
                        <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium border ${
                          upload.reviewStatus === 'approved' ? 'bg-emerald-50 text-emerald-700 border-emerald-200' :
                          upload.reviewStatus === 'refused' ? 'bg-rose-50 text-rose-700 border-rose-200' :
                          'bg-amber-50 text-amber-700 border-amber-200'
                        }`}>
                          {upload.reviewStatus === 'approved' ? <CheckCircle2 size={12} /> : 
                           upload.reviewStatus === 'refused' ? <XCircle size={12} /> : 
                           <Clock size={12} />}
                          {upload.reviewStatus === 'approved' ? 'Aprovado' : 
                           upload.reviewStatus === 'refused' ? 'Recusado' : 
                           'Pendente'}
                        </span>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-2">
                          <a 
                            href={upload.fileUrl} 
                            target="_blank" 
                            rel="noopener noreferrer"
                            className="p-2 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors"
                            title="Visualizar"
                          >
                            <Eye size={18} />
                          </a>
                          <a 
                            href={upload.fileUrl} 
                            download={upload.fileNameOriginal}
                            className="p-2 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                            title="Download"
                          >
                            <Download size={18} />
                          </a>
                          {upload.reviewStatus === 'pending' && (
                            <>
                              <button 
                                onClick={() => handleUpdateStatus(upload.id, 'approved')}
                                className="p-2 text-slate-400 hover:text-emerald-600 hover:bg-emerald-50 rounded-lg transition-colors"
                                title="Aprovar"
                              >
                                <Check size={18} />
                              </button>
                              <button 
                                onClick={() => {
                                  const note = window.prompt('Motivo da recusa:');
                                  if (note !== null) handleUpdateStatus(upload.id, 'refused', note);
                                }}
                                className="p-2 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors"
                                title="Recusar"
                              >
                                <X size={18} />
                              </button>
                            </>
                          )}
                          <button 
                            onClick={() => handleDelete(upload.id)}
                            className="p-2 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors"
                            title="Excluir"
                          >
                            <Trash2 size={18} />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
