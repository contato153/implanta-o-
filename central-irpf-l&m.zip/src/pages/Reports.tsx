import React, { useEffect, useState } from 'react';
import { 
  TrendingUp, 
  DollarSign, 
  Users, 
  FileText,
  Download,
  Calendar,
  PieChart as PieChartIcon,
  BarChart as BarChartIcon,
  Filter,
  CheckCircle2,
  Clock,
  AlertCircle
} from 'lucide-react';
import { collection, onSnapshot, query, orderBy } from 'firebase/firestore';
import { db } from '../firebase';
import { Declaration, PricingHistory, UserProfile, DeclarationStatus, Client } from '../types';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
  Legend
} from 'recharts';
import { handleFirestoreError, OperationType } from '../components/FirebaseProvider';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';

const COLORS = ['#6366f1', '#8b5cf6', '#ec4899', '#f43f5e', '#f59e0b', '#10b981', '#06b6d4'];

const STATUS_LABELS: Record<DeclarationStatus, string> = {
  new_service: 'Novo Serviço',
  link_sent: 'Link Enviado',
  waiting_docs: 'Aguardando Docs',
  docs_received: 'Docs Recebidos',
  screening: 'Triagem',
  client_pending: 'Pendência Cliente',
  in_progress: 'Em Elaboração',
  review: 'Em Revisão',
  ready_to_send: 'Pronta p/ Enviar',
  transmitted: 'Transmitida',
  finalized: 'Finalizada',
  archived: 'Arquivada',
};

export const Reports: React.FC = () => {
  const [declarations, setDeclarations] = useState<Declaration[]>([]);
  const [financials, setFinancials] = useState<PricingHistory[]>([]);
  const [clients, setClients] = useState<Client[]>([]);
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [loading, setLoading] = useState(true);
  const [exerciseFilter, setExerciseFilter] = useState('2024');

  useEffect(() => {
    const unsubDecs = onSnapshot(collection(db, 'declarations'), (snap) => {
      setDeclarations(snap.docs.map(doc => ({ id: doc.id, ...doc.data() } as Declaration)));
    }, (err) => handleFirestoreError(err, OperationType.GET, 'declarations'));

    const unsubFins = onSnapshot(collection(db, 'pricing_history'), (snap) => {
      setFinancials(snap.docs.map(doc => ({ id: doc.id, ...doc.data() } as PricingHistory)));
    }, (err) => handleFirestoreError(err, OperationType.GET, 'pricing_history'));

    const unsubClients = onSnapshot(collection(db, 'clients'), (snap) => {
      setClients(snap.docs.map(doc => ({ id: doc.id, ...doc.data() } as Client)));
    }, (err) => handleFirestoreError(err, OperationType.GET, 'clients'));

    const unsubUsers = onSnapshot(collection(db, 'users'), (snap) => {
      setUsers(snap.docs.map(doc => ({ id: doc.id, ...doc.data() } as UserProfile)));
      setLoading(false);
    }, (err) => handleFirestoreError(err, OperationType.GET, 'users'));

    return () => {
      unsubDecs();
      unsubFins();
      unsubClients();
      unsubUsers();
    };
  }, []);

  const filteredDecs = declarations.filter(d => d.exerciseYear.toString() === exerciseFilter);
  const filteredFins = financials.filter(f => f.exerciseYear.toString() === exerciseFilter);

  // Status Distribution Data
  const statusData = Object.entries(STATUS_LABELS).map(([key, label]) => ({
    name: label,
    value: filteredDecs.filter(d => d.kanbanStage === key).length
  })).filter(d => d.value > 0);

  // Productivity Data (Declarations per Responsible)
  const productivityData = users.map(user => ({
    name: (user.name || user.email || 'Usuário').split(' ')[0],
    total: filteredDecs.filter(d => d.assignedToUserId === user.id).length,
    finalized: filteredDecs.filter(d => d.assignedToUserId === user.id && d.kanbanStage === 'finalized').length
  })).filter(d => d.total > 0);

  // Financial Data
  const totalExpected = filteredFins.reduce((acc, curr) => acc + curr.finalAmount, 0);
  const totalReceived = filteredFins.filter(f => f.paymentStatus === 'paid').reduce((acc, curr) => acc + curr.finalAmount, 0);
  const totalPending = totalExpected - totalReceived;

  const financialChartData = [
    { name: 'Recebido', value: totalReceived },
    { name: 'Pendente', value: totalPending }
  ];

  // Client Ranking Data
  const clientRanking = filteredFins
    .map(f => {
      const client = clients.find(c => c.id === f.clientId);
      return {
        name: client?.name || 'Desconhecido',
        amount: f.finalAmount,
        status: f.paymentStatus
      };
    })
    .sort((a, b) => b.amount - a.amount)
    .slice(0, 5);

  const handleExportCSV = () => {
    const headers = ['Cliente', 'Exercício', 'Valor', 'Status Pagamento'];
    const rows = filteredFins.map(f => {
      const client = clients.find(c => c.id === f.clientId);
      return [
        client?.name || 'Desconhecido',
        f.exerciseYear,
        f.finalAmount,
        f.paymentStatus === 'paid' ? 'Pago' : 'Pendente'
      ];
    });

    const csvContent = [
      headers.join(','),
      ...rows.map(row => row.join(','))
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `relatorio_financeiro_${exerciseFilter}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-slate-900">Relatórios Gerenciais</h2>
          <p className="text-slate-500">Análise de desempenho e saúde financeira.</p>
        </div>
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 bg-white border border-slate-200 px-3 py-2 rounded-xl">
            <Calendar size={18} className="text-slate-400" />
            <select 
              className="text-sm font-bold text-slate-700 focus:outline-none bg-transparent"
              value={exerciseFilter}
              onChange={(e) => setExerciseFilter(e.target.value)}
            >
              <option value="2024">Exercício 2024</option>
              <option value="2023">Exercício 2023</option>
            </select>
          </div>
          <button 
            onClick={handleExportCSV}
            className="flex items-center gap-2 bg-indigo-600 text-white px-4 py-2 rounded-xl text-sm font-bold hover:bg-indigo-700 transition-all shadow-sm"
          >
            <Download size={18} />
            <span>Exportar Dados</span>
          </button>
        </div>
      </header>

      {/* Financial Summary */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
          <p className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-1">Total de Honorários</p>
          <h3 className="text-2xl font-bold text-slate-800">
            {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(totalExpected)}
          </h3>
          <div className="mt-2 flex items-center gap-1 text-xs text-emerald-600 font-medium">
            <TrendingUp size={14} />
            <span>+12% vs ano anterior</span>
          </div>
        </div>
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
          <p className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-1">Total Recebido</p>
          <h3 className="text-2xl font-bold text-emerald-600">
            {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(totalReceived)}
          </h3>
          <p className="text-xs text-slate-400 mt-2">
            {totalExpected > 0 ? ((totalReceived / totalExpected) * 100).toFixed(1) : 0}% do total
          </p>
        </div>
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
          <p className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-1">Total Pendente</p>
          <h3 className="text-2xl font-bold text-rose-600">
            {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(totalPending)}
          </h3>
          <p className="text-xs text-slate-400 mt-2">Aguardando pagamento</p>
        </div>
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
          <p className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-1">Ticket Médio</p>
          <h3 className="text-2xl font-bold text-indigo-600">
            {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(filteredDecs.length > 0 ? totalExpected / filteredDecs.length : 0)}
          </h3>
          <p className="text-xs text-slate-400 mt-2">Por declaração</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Status Distribution Chart */}
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
          <h3 className="text-lg font-bold text-slate-900 mb-6 flex items-center gap-2">
            <PieChartIcon size={20} className="text-indigo-600" />
            Distribuição por Status
          </h3>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={statusData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={100}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {statusData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip 
                  contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                />
                <Legend verticalAlign="bottom" height={36}/>
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Productivity Chart */}
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
          <h3 className="text-lg font-bold text-slate-900 mb-6 flex items-center gap-2">
            <BarChartIcon size={20} className="text-indigo-600" />
            Produtividade por Colaborador
          </h3>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={productivityData}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fill: '#64748b', fontSize: 12 }} />
                <YAxis axisLine={false} tickLine={false} tick={{ fill: '#64748b', fontSize: 12 }} />
                <Tooltip 
                  cursor={{ fill: '#f8fafc' }}
                  contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                />
                <Legend />
                <Bar dataKey="total" name="Total Atribuído" fill="#e2e8f0" radius={[4, 4, 0, 0]} />
                <Bar dataKey="finalized" name="Finalizadas" fill="#6366f1" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Financial Health Chart */}
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
          <h3 className="text-lg font-bold text-slate-900 mb-6 flex items-center gap-2">
            <DollarSign size={20} className="text-indigo-600" />
            Saúde Financeira (Recebido x Pendente)
          </h3>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={financialChartData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={100}
                  paddingAngle={5}
                  dataKey="value"
                >
                  <Cell fill="#10b981" />
                  <Cell fill="#f43f5e" />
                </Pie>
                <Tooltip 
                  formatter={(value: number) => new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(value)}
                  contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Detailed Table Placeholder */}
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
          <h3 className="text-lg font-bold text-slate-900 mb-6 flex items-center gap-2">
            <FileText size={20} className="text-indigo-600" />
            Resumo por Responsável
          </h3>
          <div className="space-y-4">
            {productivityData.map((data, idx) => (
              <div key={idx} className="flex items-center justify-between p-4 bg-slate-50 rounded-xl border border-slate-100">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full bg-indigo-100 flex items-center justify-center text-xs font-bold text-indigo-600">
                    {(data.name || 'U').charAt(0)}
                  </div>
                  <span className="font-bold text-slate-700">{data.name}</span>
                </div>
                <div className="flex gap-8">
                  <div className="text-center">
                    <p className="text-[10px] font-bold text-slate-400 uppercase">Total</p>
                    <p className="font-bold text-slate-700">{data.total}</p>
                  </div>
                  <div className="text-center">
                    <p className="text-[10px] font-bold text-slate-400 uppercase">Finalizadas</p>
                    <p className="font-bold text-emerald-600">{data.finalized}</p>
                  </div>
                  <div className="text-center">
                    <p className="text-[10px] font-bold text-slate-400 uppercase">%</p>
                    <p className="font-bold text-indigo-600">
                      {data.total > 0 ? ((data.finalized / data.total) * 100).toFixed(0) : 0}%
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Client Ranking */}
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
          <h3 className="text-lg font-bold text-slate-900 mb-6 flex items-center gap-2">
            <TrendingUp size={20} className="text-indigo-600" />
            Top 5 Clientes (Honorários)
          </h3>
          <div className="space-y-4">
            {clientRanking.map((client, idx) => (
              <div key={idx} className="flex items-center justify-between p-4 bg-slate-50 rounded-xl border border-slate-100">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full bg-slate-200 flex items-center justify-center text-xs font-bold text-slate-600">
                    {idx + 1}
                  </div>
                  <span className="font-bold text-slate-700">{client.name}</span>
                </div>
                <div className="flex items-center gap-4">
                  <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase ${
                    client.status === 'paid' ? 'bg-emerald-100 text-emerald-700' : 'bg-amber-100 text-amber-700'
                  }`}>
                    {client.status === 'paid' ? 'Pago' : 'Pendente'}
                  </span>
                  <span className="font-bold text-slate-900">
                    {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(client.amount)}
                  </span>
                </div>
              </div>
            ))}
            {clientRanking.length === 0 && (
              <p className="text-center py-8 text-slate-400 text-sm italic">Nenhum dado disponível.</p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
