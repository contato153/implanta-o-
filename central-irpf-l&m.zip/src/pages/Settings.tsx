import React, { useState, useEffect } from 'react';
import { 
  collection, 
  query, 
  onSnapshot, 
  updateDoc, 
  doc, 
  orderBy,
  where,
  setDoc,
  deleteDoc
} from 'firebase/firestore';
import { db, auth } from '../firebase';
import { 
  User, 
  Shield, 
  Settings as SettingsIcon, 
  Database, 
  History, 
  Plus, 
  Mail, 
  CheckCircle2, 
  XCircle, 
  AlertCircle,
  MoreVertical,
  Edit2,
  Trash2,
  Save,
  X
} from 'lucide-react';
import { 
  UserProfile, 
  UserRole,
  AuditLog
} from '../types';
import { handleFirestoreError, OperationType } from '../components/FirebaseProvider';
import { format, formatDistanceToNow } from 'date-fns';
import { ptBR } from 'date-fns/locale';

export const Settings: React.FC = () => {
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>([]);
  const [loading, setLoading] = useState(true);
  const [isUserModalOpen, setIsUserModalOpen] = useState(false);
  const [activeTab, setActiveTab] = useState<'users' | 'system' | 'logs'>('users');

  // System Settings State
  const [systemSettings, setSystemSettings] = useState({
    currentExercise: 2024,
    defaultDeadlineDays: 7,
    backupEnabled: true,
    notificationsEnabled: true
  });

  useEffect(() => {
    const qUsers = query(collection(db, 'users'), orderBy('createdAt', 'desc'));
    const unsubUsers = onSnapshot(qUsers, (snapshot) => {
      const docs = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as UserProfile));
      setUsers(docs);
    }, (err) => {
      handleFirestoreError(err, OperationType.GET, 'users');
    });

    const qLogs = query(collection(db, 'audit_logs'), orderBy('timestamp', 'desc'), where('timestamp', '>', '')); // Basic query
    const unsubLogs = onSnapshot(query(collection(db, 'audit_logs'), orderBy('timestamp', 'desc')), (snapshot) => {
      const docs = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as AuditLog));
      setAuditLogs(docs);
      setLoading(false);
    }, (err) => {
      handleFirestoreError(err, OperationType.GET, 'audit_logs');
      setLoading(false);
    });

    return () => {
      unsubUsers();
      unsubLogs();
    };
  }, []);

  const handleUpdateRole = async (userId: string, newRole: UserRole) => {
    try {
      await updateDoc(doc(db, 'users', userId), {
        role: newRole,
        updatedAt: new Date().toISOString()
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `users/${userId}`);
    }
  };

  const handleDeleteUser = async (userId: string) => {
    if (!window.confirm('Tem certeza que deseja remover este usuário?')) return;
    try {
      await deleteDoc(doc(db, 'users', userId));
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, `users/${userId}`);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-slate-800">Configurações</h2>
          <p className="text-slate-500">Gerencie usuários, permissões e parâmetros do sistema.</p>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-2 p-1 bg-slate-100 rounded-xl w-fit">
        <button 
          onClick={() => setActiveTab('users')}
          className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-bold transition-all ${
            activeTab === 'users' ? 'bg-white text-indigo-600 shadow-sm' : 'text-slate-500 hover:text-slate-700'
          }`}
        >
          <User size={18} />
          Usuários
        </button>
        <button 
          onClick={() => setActiveTab('system')}
          className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-bold transition-all ${
            activeTab === 'system' ? 'bg-white text-indigo-600 shadow-sm' : 'text-slate-500 hover:text-slate-700'
          }`}
        >
          <SettingsIcon size={18} />
          Sistema
        </button>
        <button 
          onClick={() => setActiveTab('logs')}
          className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-bold transition-all ${
            activeTab === 'logs' ? 'bg-white text-indigo-600 shadow-sm' : 'text-slate-500 hover:text-slate-700'
          }`}
        >
          <History size={18} />
          Logs
        </button>
      </div>

      {activeTab === 'users' && (
        <div className="space-y-6 animate-in fade-in duration-300">
          <div className="flex justify-between items-center">
            <h3 className="text-lg font-bold text-slate-800">Gerenciamento de Colaboradores</h3>
            <button 
              className="flex items-center gap-2 bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700 transition-colors shadow-sm text-sm font-bold"
            >
              <Plus size={18} />
              Convidar Usuário
            </button>
          </div>

          <div className="bg-white rounded-xl shadow-sm border border-slate-100 overflow-hidden">
            <table className="w-full text-left">
              <thead className="bg-slate-50 border-bottom border-slate-100">
                <tr>
                  <th className="px-6 py-4 text-sm font-semibold text-slate-600">Usuário</th>
                  <th className="px-6 py-4 text-sm font-semibold text-slate-600">E-mail</th>
                  <th className="px-6 py-4 text-sm font-semibold text-slate-600">Nível de Acesso</th>
                  <th className="px-6 py-4 text-sm font-semibold text-slate-600">Data de Cadastro</th>
                  <th className="px-6 py-4 text-sm font-semibold text-slate-600">Ações</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {users.map((user) => (
                  <tr key={user.id} className="hover:bg-slate-50 transition-colors">
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-full bg-indigo-100 flex items-center justify-center text-xs font-bold text-indigo-600">
                          {(user.name || user.email || 'U').charAt(0)}
                        </div>
                        <span className="font-medium text-slate-800">{user.name || 'Usuário Sem Nome'}</span>
                      </div>
                    </td>
                    <td className="px-6 py-4 text-sm text-slate-600">{user.email}</td>
                    <td className="px-6 py-4">
                      <select 
                        className={`text-xs font-bold px-2 py-1 rounded-lg border focus:outline-none ${
                          user.role === 'admin' ? 'bg-rose-50 text-rose-700 border-rose-200' :
                          user.role === 'gestor' ? 'bg-blue-50 text-blue-700 border-blue-200' :
                          'bg-slate-50 text-slate-700 border-slate-200'
                        }`}
                        value={user.role}
                        onChange={(e) => handleUpdateRole(user.id, e.target.value as UserRole)}
                        disabled={user.email === 'lucas@lemcontabilidade.com'}
                      >
                        <option value="admin">Administrador</option>
                        <option value="gestor">Gestor</option>
                        <option value="analista">Analista</option>
                      </select>
                    </td>
                    <td className="px-6 py-4 text-sm text-slate-600">
                      {user.createdAt ? format(new Date(user.createdAt), 'dd/MM/yyyy') : '-'}
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-2">
                        <button 
                          onClick={() => handleDeleteUser(user.id)}
                          disabled={user.email === 'lucas@lemcontabilidade.com'}
                          className="p-2 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors disabled:opacity-30 disabled:cursor-not-allowed"
                        >
                          <Trash2 size={18} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {activeTab === 'system' && (
        <div className="max-w-2xl space-y-6 animate-in fade-in duration-300">
          <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 space-y-6">
            <h3 className="text-lg font-bold text-slate-800 flex items-center gap-2">
              <SettingsIcon size={20} className="text-indigo-600" />
              Parâmetros do Sistema
            </h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Exercício Atual</label>
                <select 
                  className="w-full p-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  value={systemSettings.currentExercise}
                  onChange={(e) => setSystemSettings({ ...systemSettings, currentExercise: Number(e.target.value) })}
                >
                  <option value="2024">2024</option>
                  <option value="2023">2023</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Prazo Padrão (Dias)</label>
                <input 
                  type="number"
                  className="w-full p-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  value={systemSettings.defaultDeadlineDays}
                  onChange={(e) => setSystemSettings({ ...systemSettings, defaultDeadlineDays: Number(e.target.value) })}
                />
              </div>
            </div>

            <div className="space-y-4 pt-4 border-t border-slate-100">
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-bold text-slate-800">Backup Automático</p>
                  <p className="text-sm text-slate-500">Realizar backup diário dos dados na nuvem.</p>
                </div>
                <button 
                  onClick={() => setSystemSettings({ ...systemSettings, backupEnabled: !systemSettings.backupEnabled })}
                  className={`w-12 h-6 rounded-full transition-colors relative ${systemSettings.backupEnabled ? 'bg-indigo-600' : 'bg-slate-300'}`}
                >
                  <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-all ${systemSettings.backupEnabled ? 'left-7' : 'left-1'}`} />
                </button>
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-bold text-slate-800">Notificações por E-mail</p>
                  <p className="text-sm text-slate-500">Enviar alertas de novos documentos e prazos.</p>
                </div>
                <button 
                  onClick={() => setSystemSettings({ ...systemSettings, notificationsEnabled: !systemSettings.notificationsEnabled })}
                  className={`w-12 h-6 rounded-full transition-colors relative ${systemSettings.notificationsEnabled ? 'bg-indigo-600' : 'bg-slate-300'}`}
                >
                  <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-all ${systemSettings.notificationsEnabled ? 'left-7' : 'left-1'}`} />
                </button>
              </div>
            </div>

            <div className="flex justify-end pt-4">
              <button className="flex items-center gap-2 bg-indigo-600 text-white px-6 py-2 rounded-lg hover:bg-indigo-700 transition-colors shadow-sm font-bold">
                <Save size={18} />
                Salvar Alterações
              </button>
            </div>
          </div>

          <div className="bg-rose-50 p-6 rounded-2xl border border-rose-100">
            <h3 className="text-lg font-bold text-rose-800 flex items-center gap-2 mb-2">
              <AlertCircle size={20} />
              Zona de Perigo
            </h3>
            <p className="text-sm text-rose-700 mb-4">Ações irreversíveis que impactam todo o sistema.</p>
            <button className="bg-rose-600 text-white px-4 py-2 rounded-lg hover:bg-rose-700 transition-colors text-sm font-bold shadow-sm">
              Limpar Cache do Sistema
            </button>
          </div>
        </div>
      )}

      {activeTab === 'logs' && (
        <div className="bg-white rounded-xl shadow-sm border border-slate-100 overflow-hidden animate-in fade-in duration-300">
          <div className="p-6 border-b border-slate-100">
            <h3 className="text-lg font-bold text-slate-800">Log de Atividades Recentes</h3>
          </div>
          <div className="divide-y divide-slate-100">
            {auditLogs.slice(0, 50).map((log) => (
              <div key={log.id} className="p-4 flex gap-4 items-start hover:bg-slate-50 transition-colors">
                <div className="p-2 bg-slate-100 rounded-lg text-slate-500 mt-1">
                  <Database size={16} />
                </div>
                <div className="flex-1">
                  <p className="text-sm text-slate-800">
                    <span className="font-bold">{log.userName}</span> {log.action}
                    {log.details && typeof log.details === 'string' && (
                      <span className="text-slate-500 ml-1">— {log.details}</span>
                    )}
                  </p>
                  <p className="text-xs text-slate-400 mt-1">
                    {log.timestamp && formatDistanceToNow(
                      log.timestamp.toDate ? log.timestamp.toDate() : new Date(log.timestamp), 
                      { addSuffix: true, locale: ptBR }
                    )}
                  </p>
                </div>
              </div>
            ))}
            {auditLogs.length === 0 && (
              <div className="p-8 text-center text-slate-500 italic">Nenhum log de atividade encontrado.</div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
